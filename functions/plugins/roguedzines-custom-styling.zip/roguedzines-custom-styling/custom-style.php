<?php
/*
Plugin Name: RogueDzines Custom Styles
Plugin URI: http://www.roguedzines.com
Description: Add custom styles in your posts and pages content using TinyMCE WYSIWYG editor. The plugin adds a Styles dropdown menu in the visual post editor.
Based on TinyMCE Kit plug-in for WordPress

*/
/**
 * Apply styles to the visual editor
 */
add_filter('mce_css', 'roguedzines_mcekit_editor_style');
function roguedzines_mcekit_editor_style($url) {

    if ( !empty($url) )
        $url .= ',';

    // Retrieves the plugin directory URL
    // Change the path here if using different directories
    $url .= trailingslashit( plugin_dir_url(__FILE__) ) . 'editor-styles.css';

    return $url;
}

/**
 * Add "Styles" drop-down
 */
add_filter( 'mce_buttons_2', 'roguedzines_mce_editor_buttons' );

function roguedzines_mce_editor_buttons( $buttons ) {
    array_unshift( $buttons, 'styleselect' );
    return $buttons;
}

/**
 * Add styles/classes to the "Styles" drop-down
 */
add_filter( 'tiny_mce_before_init', 'roguedzines_mce_before_init' );

function roguedzines_mce_before_init( $settings ) {

    $style_formats = array(
        array(
            'title' => 'Download Link',
            'selector' => 'a',
            'classes' => 'download'
            ),
        array(
            'title' => 'Third Size Box',
            'block' => 'div',
            'classes' => 'third-size box',
            'wrapper' => true
        ),
        array(
            'title' => 'Left Box',
            'block' => 'div',
            'classes' => 'left box',
            'wrapper' => true
        ),
        array(
            'title' => 'Right Size Box',
            'block' => 'div',
            'classes' => 'right box',
            'wrapper' => true
        ),
        array(
            'title' => 'Full Width Box',
            'block' => 'div',
            'classes' => 'full-width box',
            'wrapper' => true
        ),
        array(
            'title' => 'Pink Button',
            'selector' => 'a',
            'classes' => 'page-cta'
        ),
        array(
            'title' => 'Gray Button',
            'selector' => 'a',
            'classes' => 'gray-cta'
        ),
        array(
            'title' => 'Green CTA',
            'selector' => 'a',
            'classes' => 'green-cta'
        ),
        array(
            'title' => 'Yellow CTA',
            'selector' => 'a',
            'classes' => 'yellow-cta'
        )
    );

    $settings['style_formats'] = json_encode( $style_formats );

    return $settings;

}

/* Learn TinyMCE style format options at http://www.tinymce.com/wiki.php/Configuration:formats */

/*
 * Add custom stylesheet to the website front-end with hook 'wp_enqueue_scripts'
 */
add_action('wp_enqueue_scripts', 'roguedzines_mcekit_editor_enqueue');

/*
 * Enqueue stylesheet, if it exists.
 */
function roguedzines_mcekit_editor_enqueue() {
  $StyleUrl = plugin_dir_url(__FILE__).'editor-styles.css'; // Customstyle.css is relative to the current file
  wp_enqueue_style( 'myCustomStyles', $StyleUrl );
}
?>
